Main class is HelloApplication.java
