Contains all the .fxml pages used in the lecturer section of the application
