Uses alot of CSS styling added in the scene builder. Includes the external .css file used by every .fxml file as well as the icon image.
