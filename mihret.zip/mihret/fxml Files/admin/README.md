Contains all the .fxml pages used in the admin section of the application
